/**
 * API Service Layer
 * Connects React frontend to Flask backend (port 5001)
 */

const API_BASE = 'http://localhost:5001/api';

/**
 * Fetch stock data from backend
 * @param {string} ticker - Stock symbol (e.g., 'AAPL')
 * @returns {Promise<Object>} Stock data with prices, fundamentals, etc.
 */
export async function fetchStockData(ticker) {
  try {
    const response = await fetch(`${API_BASE}/stock/${ticker.toUpperCase()}`);
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || `Failed to fetch ${ticker}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error(`Error fetching stock data for ${ticker}:`, error);
    throw error;
  }
}

/**
 * Fetch SPY (S&P 500) data for Relative Strength calculation
 * @returns {Promise<Object>} SPY data with current price and historical prices
 */
export async function fetchSPYData() {
  try {
    const response = await fetch(`${API_BASE}/market/spy`);
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to fetch SPY data');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching SPY data:', error);
    throw error;
  }
}

/**
 * Check if backend is healthy
 * @returns {Promise<boolean>} True if backend is running
 */
export async function checkHealth() {
  try {
    const response = await fetch(`${API_BASE}/health`);
    return response.ok;
  } catch (error) {
    console.error('Backend health check failed:', error);
    return false;
  }
}

/**
 * Fetch both stock and SPY data in parallel
 * @param {string} ticker - Stock symbol
 * @returns {Promise<Object>} Combined stock and SPY data
 */
export async function fetchAnalysisData(ticker) {
  try {
    const [stockData, spyData] = await Promise.all([
      fetchStockData(ticker),
      fetchSPYData()
    ]);
    
    return {
      stock: stockData,
      spy: spyData,
      fetchedAt: new Date().toISOString()
    };
  } catch (error) {
    console.error('Error fetching analysis data:', error);
    throw error;
  }
}
